__author__= "Prithvi Singh"

from .dual import Dual

__all__= [
    "Dual"
]