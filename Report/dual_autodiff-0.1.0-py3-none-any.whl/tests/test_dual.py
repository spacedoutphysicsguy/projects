# test_dual.py
import pytest
import numpy as np
from dual_autodiff.dual import Dual

class TestDual:
    def test_initialization(self):
        d = Dual(3.0, 2.0)
        assert d.real == 3.0
        assert d.dual == 2.0

    def test_repr(self):
        d = Dual(3.0, 2.0)
        assert repr(d) == "(3.0,2.0)"

    def test_str(self):
        d = Dual(3.0, 2.0)
        assert str(d) == "Dual(real=3.0,dual=2.0)"

    def test_addition(self):
        d1 = Dual(3.0, 2.0)
        d2 = Dual(1.0, 4.0)
        result = d1 + d2
        assert result.real == 4.0
        assert result.dual == 6.0

    def test_subtraction(self):
        d1 = Dual(3.0, 2.0)
        d2 = Dual(1.0, 4.0)
        result = d1 - d2
        assert result.real == 2.0
        assert result.dual == -2.0

    def test_multiplication(self):
        d1 = Dual(3.0, 2.0)
        d2 = Dual(1.0, 4.0)
        result = d1 * d2
        assert result.real == 3.0
        assert result.dual == 14.0  # 2*1 + 3*4

    def test_division(self):
        d1 = Dual(3.0, 2.0)
        d2 = Dual(1.0, 4.0)
        result = d1 / d2
        assert result.real == 3.0
        assert result.dual == -10.0  # (2*1 - 3*4) / (1^2)

    def test_exponentiation(self):
        d1 = Dual(2.0, 3.0)
        result = d1 ** 2
        assert result.real == 4.0
        assert result.dual == 12.0  # 2^2 * (3/2 + 0)

    def test_sin(self):
        d = Dual(np.pi / 2, 1.0)
        result = d.sin()
        assert np.isclose(result.real, 1.0)
        assert np.isclose(result.dual, 0.0)

    def test_cos(self):
        d = Dual(0.0, 1.0)
        result = d.cos()
        assert np.isclose(result.real, 1.0)
        assert np.isclose(result.dual, 0.0)

    def test_tan(self):
        d = Dual(np.pi / 4, 1.0)
        result = d.tan()
        assert np.isclose(result.real, 1.0)
        assert np.isclose(result.dual, 2.0)

    def test_log(self):
        d = Dual(np.e, 1.0)
        result = d.log()
        assert np.isclose(result.real, 1.0)
        assert np.isclose(result.dual, 1.0/np.e)
    

    def test_exp(self):
        d = Dual(1.0, 1.0)
        result = d.exp()
        assert np.isclose(result.real, np.e)
        assert np.isclose(result.dual, np.e)

    def test_relu(self):
        d1 = Dual(3.0, 2.0)
        result = d1.relu()
        assert result.real == 3.0
        assert result.dual == 1.0

        d2 = Dual(-1.0, 2.0)
        result = d2.relu()
        assert result.real == 0.0
        assert result.dual == 0.0

    def test_sigmoid(self):
        d = Dual(0.0, 1.0)
        result = d.sigmoid()
        assert np.isclose(result.real, 0.5)
        assert np.isclose(result.dual, 0.25)